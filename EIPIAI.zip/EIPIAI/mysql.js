const mysql = require('mysql');

var pool = mysql.createPool({
    user: 'root',
    database: 'APIuser',

    host: '127.0.0.1',

})

exports.pool = pool;
